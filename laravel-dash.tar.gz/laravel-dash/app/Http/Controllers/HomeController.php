<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class HomeController extends Controller
{
	function runCmd($cmd, $output= '', $returnVar = -1){
		try{
			$cmd  = "$cmd 2>&1";
			exec($cmd, $output, $returnVar);
			if($returnVar ===0)
				return implode("\n",$output);
			else 
				throw new \Exception('Method not found or invalid argument');
		}
		catch(\Exception $e){
			return ['error'=>$e->getMessage()];
		}
	}

	function getListTransaction(Request $req){
		$limit = isset($req->limit) ? (int)$req->limit : 100;
		$list = json_decode($this->runCmd("dash-cli listtransactions"));
		usort($list,function($a,$b){
			return $b->timereceived <=> $a->timereceived;
		});
		$result = [];
		$count = 1;
		foreach($list as $trans){
			if($trans->category == 'receive'){
				$result[$count]['txid'] = $trans->txid;
				$result[$count]['address'] = $trans->address;
				$result[$count]['amount'] = $trans->amount;	
				$count++;
				if($count==$limit) break;		
			}
		}
		return $result;
	}

	function getDetailTransaction(Request $req){
		$cmd = "dash-cli gettransaction $req->txid";
		return $this->runCmd($cmd);
	}

	function getTotalBalance(){
		return ['totalBalance'=>$this->runCmd("dash-cli getbalance")];
	}

	function getListAddress(){
		return $this->runCmd("dash-cli getaddressesbyaccount \"\"");
	}

	function getNewAddress(){
		return ['address'=>$this->runCmd("dash-cli getnewaddress")];
	}
	
	function sendToDashAddress(Request $req){
		$cmd = "dash-cli sendtoaddress $req->dashaddress $req->amount";
		return ['txid'=>$this->runCmd($cmd)];
	}

	function walletPassphrase(Request $req){
		return $this->runCmd("dash-cli walletpassphrase \"$req->passphrase\" 120"); //2mins
	}



	function sendFromDashAddress(Request $req){
		$cmd = "dash-cli sendfrom \"$req->fromaccount\" \"$req->dashaddress\" $req->amount";
		//return $cmd;
		return $this->runCmd($cmd);
	}


	function getBalanceByAddress(Request $req){
		
	}


}

