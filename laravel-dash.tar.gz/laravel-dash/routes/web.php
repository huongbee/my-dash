
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('list-transaction/{limit?}',[
    'uses'=>"HomeController@getListTransaction"
]);

Route::get('detail-transaction/{txid}',[
    'uses'=>'HomeController@getDetailTransaction'
]);

Route::get('total-balance',[
    'uses'=>'HomeController@getTotalBalance'
]);

Route::get('listaddress', [
    'uses'=>'HomeController@getListAddress',
    'as'=>'listaddress'    
]);

Route::get('newaddress', [
    'uses'=>'HomeController@getNewAddress',
    'as'=>'newaddress'    
]);
//XfFJvXyqdcZgW2VVHLhBDacTVAyxq5wHkk
//XrCfXHPENRXY6MDM7wf9xG8Rc5pxLw7LL5
Route::get('sendtodashaddress/{dashaddress}/{amount}',[
	'uses'=>'HomeController@sendToDashAddress',
    'as'=>'sendtodashaddress' 
]);


// 



Route::get('getbalance/{address}', [
    'uses'=>'HomeController@getBalanceByAddress',
    'as'=>'getbalance'    
]);

Route::get('sendfrom/{fromaccount}/{dashaddress}/{amount}',[
	'uses'=>'HomeController@sendFromDashAddress',
    'as'=>'sendfrom' 
]);

Route::get('walletpassphrase/{passphrase}',[
    'uses'=>'HomeController@walletPassphrase',
    'as'=>'walletpassphrase' 
]);


Route::get('test',function(){
        $ip = $_SERVER['REMOTE_ADDR'];
        $details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
        print_r($details); 
        echo "<br>";
        echo $_SERVER['HTTP_USER_AGENT'];
        echo "<br>";
        
        echo getHostByName(getHostName());

        echo "<br>";
        echo $_SERVER['REMOTE_ADDR'];
        echo "<br>";
        
        echo \Request::ip();
        echo "<br>";
        echo gethostname();
        echo "<br>";
       
        echo php_uname();
});